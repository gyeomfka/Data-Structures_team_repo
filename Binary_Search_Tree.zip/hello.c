#include<stdio.h>

int main(){
    printf("hello\n");
    printf("hello");
    printf("hello");
    printf("hello");
    printf("hello");
    printf("hello");
    getchar();
}